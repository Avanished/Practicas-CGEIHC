#include <stdio.h>
#include <string.h>
#include <stdlib.h>   // A�ADIDO para rand() y srand()
#include <time.h>     // A�ADIDO para time()
#include <glew.h>
#include <glfw3.h>

//Dimensiones de la ventana
const int WIDTH = 800, HEIGHT = 800;
GLuint VAO, VBO, shader;
//VAO Vertex array object: Declara los vertices a utilizar
//VBAO Vertex Buffer Object: Asigna los valores de los vertices a utilizar
//Shader: Para los colores

//LENGUAJE DE SHADER (SOMBRAS) GLSL
//Vertex Shader
//recibir color, salida Vcolor
static const char* vShader = "						\n\
#version 330										\n\
layout (location =0) in vec3 pos;					\n\
void main()											\n\
{													\n\
gl_Position=vec4(pos.x,pos.y,pos.z,1.0f); 			\n\
}";

//Fragment Shader
//recibir Vcolor y dar de salida color
static const char* fShader = "						\n\
#version 330										\n\
out vec4 color;										\n\
void main()											\n\
{													\n\
	color = vec4(1.0f,1.0f,1.0f,1.0f);	 			\n\
}";

void CrearTriangulo()
{
	GLfloat vertices[] = {
		//  X      Y     Z
		//Formando LETRA A
		//Triangulo 123
		-1.0f, -1.0f,0.0f, //1
		-1.0f,-0.60f, 0.0f,  //2
		-0.85f,-1.0f,0.0f,  //3
		//Triangulo 234
		-1.0f,-0.60f, 0.0f,  //2
		-0.85f,-1.0f,0.0f,  //3
		-0.85f,-0.60f,0.0f,  //4
		//Triangulo 567
		-0.60f,-0.60f, 0.0f,  //5
		-0.45f,-0.60f,0.0f,  //6
		-0.45f,-1.00f,0.0f,  //7
		//Triangulo 578
		-0.60f,-0.60f, 0.0f,  //5
		-0.45f,-1.00f,0.0f,  //7
		-0.60f,-1.00f,0.0f,  //8
		//Triangulo 4,5,9
		-0.85f,-0.60f,0.0f,  //4
		-0.60f,-0.60f, 0.0f,  //5
		-0.85f,-0.70f,0.0f,  //9
		//Triangulo 5,9,10
		-0.60f,-0.60f, 0.0f,  //5
		-0.85f,-0.70f,0.0f,  //9
		-0.60f,-0.70f, 0.0f,  //10
		//Triangulo 11,12,13
		-0.85f,-0.80f,0.0f,  //11
		-0.60f,-0.80f, 0.0f,  //12
		-0.85f,-0.90f,0.0f,  //13
		//Triangulo 12,13,14
		-0.60f,-0.80f, 0.0f,  //12
		-0.85f,-0.90f,0.0f,  //13
		-0.60f,-0.90f, 0.0f,  //14

		//Formato letra R
		//Triangulo 1,2,3 Palo izquierdo
		-0.20f, -0.40f, 0.0f, //1
		-0.20f,  0.00f, 0.0f, //2
		-0.10f,  0.00f, 0.0f, //3
		//Triangulo 1,3,4
		-0.20f, -0.40f, 0.0f, //1
		-0.10f,  0.00f, 0.0f, //3
		-0.10f, -0.40f, 0.0f, //4
		//Triangulo 3,5,6 Barra superior del bulto
		-0.10f,  0.00f, 0.0f, //3
		 0.10f,  0.00f, 0.0f, //5
		-0.10f, -0.07f, 0.0f, //6
		//Triangulo 5,6,7
		 0.10f,  0.00f, 0.0f, //5
		 0.10f, -0.07f, 0.0f, //7
		-0.10f, -0.07f, 0.0f, //6
		//Triangulo 5,8,9 Lado derecho del bulto
		 0.10f,  0.00f, 0.0f, //5
		 0.20f,  0.00f, 0.0f, //8
		 0.20f, -0.20f, 0.0f, //9
		 //Triangulo 5,7,9
		  0.10f,  0.00f, 0.0f, //5
		  0.10f, -0.20f, 0.0f, //7
		  0.20f, -0.20f, 0.0f, //9
		  //Triangulo 6,9,10 Barra inferior del bulto
		  -0.10f, -0.20f, 0.0f, //6
		   0.20f, -0.20f, 0.0f, //9
		  -0.10f, -0.27f, 0.0f, //10
		  //Triangulo 9,10,11
		   0.20f, -0.20f, 0.0f, //9
		   0.20f, -0.27f, 0.0f, //11
		  -0.10f, -0.27f, 0.0f, //10
		  //Triangulo 10,12,13 Pata diagonal
		  -0.10f, -0.27f, 0.0f, //10
		   0.05f, -0.27f, 0.0f, //12
		   0.20f, -0.40f, 0.0f, //13
		   //Triangulo 10,13,14
		   -0.10f, -0.27f, 0.0f, //10
			0.05f, -0.40f, 0.0f, //14
			0.20f, -0.40f, 0.0f, //13

			//Formato letra C
			//Triangulo 1,2,3 Palo izquierdo
			 0.70f,  0.62f, 0.0f, //1
			 0.70f,  1.00f, 0.0f, //2
			 0.80f,  1.00f, 0.0f, //3
			 //Triangulo 1,3,4
			  0.70f,  0.62f, 0.0f, //1
			  0.80f,  0.62f, 0.0f, //4
			  0.80f,  1.00f, 0.0f, //3
			  //Triangulo 3,5,6 Barra superior
			   0.80f,  0.90f, 0.0f, //3
			   1.00f,  0.90f, 0.0f, //5
			   0.80f,  1.00f, 0.0f, //6
			   //Triangulo 5,6,7
				1.00f,  0.90f, 0.0f, //5
				1.00f,  1.00f, 0.0f, //7
				0.80f,  1.00f, 0.0f, //6
				//Triangulo 4,8,9 Barra inferior
				 0.80f,  0.62f, 0.0f, //4
				 1.00f,  0.62f, 0.0f, //8
				 0.80f,  0.72f, 0.0f, //9
				 //Triangulo 8,9,10
				  1.00f,  0.62f, 0.0f, //8
				  1.00f,  0.72f, 0.0f, //10
				  0.80f,  0.72f, 0.0f, //9
	};

	glGenVertexArrays(1, &VAO); //generar 1 VAO
	glBindVertexArray(VAO);//asignar VAO

	glGenBuffers(1, &VBO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW); //pasarle los datos al VBO asignando tamano, los datos y en este caso es est�tico pues no se modificar�n los valores

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GL_FLOAT), (GLvoid*)0);//Stride en caso de haber datos de color por ejemplo, es saltar cierta cantidad de datos
	glEnableVertexAttribArray(0);
	//agregar valores a v�rtices y luego declarar un nuevo vertexAttribPointer
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
}

void AddShader(GLuint theProgram, const char* shaderCode, GLenum shaderType) //Funci�n para agregar los shaders a la tarjeta gr�fica
//the Program recibe los datos de theShader
{
	GLuint theShader = glCreateShader(shaderType);//theShader es un shader que se crea de acuerdo al tipo de shader: vertex o fragment
	const GLchar* theCode[1];
	theCode[0] = shaderCode;//shaderCode es el texto que se le pasa a theCode
	GLint codeLength[1];
	codeLength[0] = strlen(shaderCode);//longitud del texto
	glShaderSource(theShader, 1, theCode, codeLength);//Se le asigna al shader el c�digo
	glCompileShader(theShader);//Se comila el shader
	GLint result = 0;
	GLchar eLog[1024] = { 0 };
	//verificaciones y prevenci�n de errores
	glGetShaderiv(theShader, GL_COMPILE_STATUS, &result);
	if (!result)
	{
		glGetProgramInfoLog(shader, sizeof(eLog), NULL, eLog);
		printf("EL error al compilar el shader %d es: %s \n", shaderType, eLog);
		return;
	}
	glAttachShader(theProgram, theShader);//Si no hubo problemas se asigna el shader a theProgram el cual asigna el c�digo a la tarjeta gr�fica
}

void CompileShaders() {
	shader = glCreateProgram(); //se crea un programa
	if (!shader)
	{
		printf("Error creando el shader");
		return;
	}
	AddShader(shader, vShader, GL_VERTEX_SHADER);//Agregar vertex shader
	AddShader(shader, fShader, GL_FRAGMENT_SHADER);//Agregar fragment shader
	//Para terminar de linkear el programa y ver que no tengamos errores
	GLint result = 0;
	GLchar eLog[1024] = { 0 };
	glLinkProgram(shader);//se linkean los shaders a la tarjeta gr�fica
	//verificaciones y prevenci�n de errores
	glGetProgramiv(shader, GL_LINK_STATUS, &result);
	if (!result)
	{
		glGetProgramInfoLog(shader, sizeof(eLog), NULL, eLog);
		printf("EL error al linkear es: %s \n", eLog);
		return;
	}
	glValidateProgram(shader);
	glGetProgramiv(shader, GL_VALIDATE_STATUS, &result);
	if (!result)
	{
		glGetProgramInfoLog(shader, sizeof(eLog), NULL, eLog);
		printf("EL error al validar es: %s \n", eLog);
		return;
	}
}

int main()
{
	//Inicializaci�n de GLFW
	if (!glfwInit())
	{
		printf("Fall� inicializar GLFW");
		glfwTerminate();
		return 1;
	}

	//****  LAS SIGUIENTES 4 L�NEAS SE COMENTAN EN DADO CASO DE QUE AL USUARIO NO LE FUNCIONE LA VENTANA Y PUEDA CONOCER LA VERSI�N DE OPENGL QUE TIENE ****/

	//Asignando variables de GLFW y propiedades de ventana
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	//para solo usar el core profile de OpenGL y no tener retrocompatibilidad
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

	//CREAR VENTANA
	GLFWwindow* mainWindow = glfwCreateWindow(WIDTH, HEIGHT, "Primer ventana", NULL, NULL);

	if (!mainWindow)
	{
		printf("Fallo en crearse la ventana con GLFW");
		glfwTerminate();
		return 1;
	}
	//Obtener tama�o de Buffer
	int BufferWidth, BufferHeight;
	glfwGetFramebufferSize(mainWindow, &BufferWidth, &BufferHeight);

	//asignar el contexto
	glfwMakeContextCurrent(mainWindow);

	//permitir nuevas extensiones
	glewExperimental = GL_TRUE;

	if (glewInit() != GLEW_OK)
	{
		printf("Fall� inicializaci�n de GLEW");
		glfwDestroyWindow(mainWindow);
		glfwTerminate();
		return 1;
	}

	// Asignar valores de la ventana y coordenadas
	//Asignar Viewport
	glViewport(0, 0, BufferWidth, BufferHeight);

	//Llamada a las funciones creadas antes del main
	CrearTriangulo();
	CompileShaders();

	// ========== INICIO DE MODIFICACI�N PARA COLOR ALEATORIO ==========
	srand(time(NULL));               // Semilla para n�meros aleatorios (diferente en cada ejecuci�n)
	double ultimoCambio = glfwGetTime(); // Tiempo del �ltimo cambio de color
	float r = (float)rand() / RAND_MAX; // Componente rojo inicial aleatorio
	float g = (float)rand() / RAND_MAX; // Componente verde inicial aleatorio
	float b = (float)rand() / RAND_MAX; // Componente azul inicial aleatorio
	// ========== FIN DE MODIFICACI�N ==========

	//Loop mientras no se cierra la ventana
	while (!glfwWindowShouldClose(mainWindow))
	{
		// Recibir eventos del usuario
		glfwPollEvents();

		// ========== MODIFICACI�N DEL C�LCULO DE COLOR ==========
		double tiempoActual = glfwGetTime();
		// Si ha pasado al menos 2 segundos desde el �ltimo cambio, generamos nuevos colores
		if (tiempoActual - ultimoCambio >= 2.0) {
			r = (float)rand() / RAND_MAX;
			g = (float)rand() / RAND_MAX;
			b = (float)rand() / RAND_MAX;
			ultimoCambio = tiempoActual; // Actualizamos la marca de tiempo
		}
		// Establecemos el color de fondo (puede ser el mismo si no ha pasado el intervalo)
		glClearColor(r, g, b, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);
		// ========== FIN DE MODIFICACI�N ==========

		glUseProgram(shader);

		glBindVertexArray(VAO);
		//Se dibujan triangulos
		glDrawArrays(GL_TRIANGLES, 0, 72);
		// Se dibujan puntos
		//glDrawArrays(GL_Points, 0, 6)
		// Se dibujan lineas
		//glDrawArrays(GL_Lines, 0, 6)
		glBindVertexArray(0);
		glUseProgram(0);

		glfwSwapBuffers(mainWindow);
	}
	//NO ESCRIBIR NINGUNA L�NEA DESPU�S DE glfwSwapBuffers(mainWindow); 

	return 0;
}