#pragma once
#include<stdio.h>
#include<glew.h>
#include<glfw3.h>

class Window
{
public:
	Window();
	Window(GLint windowWidth, GLint windowHeight);
	int Initialise();
	GLfloat getBufferWidth() { return bufferWidth; }
	GLfloat getBufferHeight() { return bufferHeight; }
	bool getShouldClose() { return glfwWindowShouldClose(mainWindow); }
	bool* getsKeys() { return keys; }
	GLFWwindow* getGLFWwindow() { return mainWindow; }
	GLfloat getXChange();
	GLfloat getYChange();
	void swapBuffers() { return glfwSwapBuffers(mainWindow); }
	GLfloat getrotay() { return rotay; }
	GLfloat getrotax() { return rotax; }
	GLfloat getrotaz() { return rotaz; }
	// orejas
	GLfloat getarticulacion1() { return articulacion1; }  // oreja izquierda
	GLfloat getarticulacion2() { return articulacion2; }  // oreja derecha
	// cola
	GLfloat getarticulacion3() { return articulacion3; }  // segmento 1 cola
	GLfloat getarticulacion4() { return articulacion4; }  // segmento 2 cola
	// pata delantera derecha
	GLfloat getarticulacion5() { return articulacion5; }  // muslo
	GLfloat getarticulacion6() { return articulacion6; }  // rodilla
	// pata delantera izquierda
	GLfloat getarticulacion7() { return articulacion7; }  // muslo
	GLfloat getarticulacion8() { return articulacion8; }  // rodilla
	// pata trasera derecha
	GLfloat getarticulacion9() { return articulacion9; }  // muslo
	GLfloat getarticulacion10() { return articulacion10; } // rodilla
	// pata trasera izquierda
	GLfloat getarticulacion11() { return articulacion11; } // muslo
	GLfloat getarticulacion12() { return articulacion12; } // rodilla

	~Window();
private:
	GLFWwindow* mainWindow;
	GLint width, height;
	GLfloat rotax, rotay, rotaz;
	GLfloat articulacion1, articulacion2, articulacion3, articulacion4,
		articulacion5, articulacion6, articulacion7, articulacion8,
		articulacion9, articulacion10, articulacion11, articulacion12;
	bool keys[1024];
	GLint bufferWidth, bufferHeight;
	GLfloat lastX, lastY, xChange, yChange;
	bool mouseFirstMoved;
	void createCallbacks();
	static void ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode);
	static void ManejaMouse(GLFWwindow* window, double xPos, double yPos);
};