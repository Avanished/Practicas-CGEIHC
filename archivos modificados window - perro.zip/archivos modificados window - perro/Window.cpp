#include "Window.h"
#include <stdio.h>

Window::Window()
{
	width = 800;
	height = 600;
	for (size_t i = 0; i < 1024; i++) keys[i] = 0;
	xChange = 0.0f;
	yChange = 0.0f;
	rotax = 0.0f; rotay = 0.0f; rotaz = 0.0f;
	articulacion1 = 0.0f; articulacion2 = 0.0f;
	articulacion3 = 0.0f; articulacion4 = 0.0f;
	articulacion5 = 0.0f; articulacion6 = 0.0f;
	articulacion7 = 0.0f; articulacion8 = 0.0f;
	articulacion9 = 0.0f; articulacion10 = 0.0f;
	articulacion11 = 0.0f; articulacion12 = 0.0f;
}

Window::Window(GLint windowWidth, GLint windowHeight)
{
	width = windowWidth;
	height = windowHeight;
	for (size_t i = 0; i < 1024; i++) keys[i] = 0;
	xChange = 0.0f;
	yChange = 0.0f;
	rotax = 0.0f; rotay = 0.0f; rotaz = 0.0f;
	articulacion1 = 0.0f; articulacion2 = 0.0f;
	articulacion3 = 0.0f; articulacion4 = 0.0f;
	articulacion5 = 0.0f; articulacion6 = 0.0f;
	articulacion7 = 0.0f; articulacion8 = 0.0f;
	articulacion9 = 0.0f; articulacion10 = 0.0f;
	articulacion11 = 0.0f; articulacion12 = 0.0f;
}

int Window::Initialise()
{
	if (!glfwInit())
	{
		printf("GLFW no se inicializ�\n");
		glfwTerminate();
		return 1;
	}

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

	mainWindow = glfwCreateWindow(width, height, "Practica 4 - Perro Jerarquico", NULL, NULL);
	if (!mainWindow)
	{
		printf("Ventana GLFW no se cre�\n");
		glfwTerminate();
		return 1;
	}

	glfwGetFramebufferSize(mainWindow, &bufferWidth, &bufferHeight);
	glfwMakeContextCurrent(mainWindow);
	createCallbacks();
	glfwSwapInterval(1);

	glewExperimental = GL_TRUE;
	if (glewInit() != GLEW_OK)
	{
		printf("GLEW no se inicializ�\n");
		glfwDestroyWindow(mainWindow);
		glfwTerminate();
		return 1;
	}

	glEnable(GL_DEPTH_TEST);
	glViewport(0, 0, bufferWidth, bufferHeight);
	glfwSetWindowUserPointer(mainWindow, this);

	return 0;
}

void Window::createCallbacks()
{
	glfwSetKeyCallback(mainWindow, ManejaTeclado);
	glfwSetCursorPosCallback(mainWindow, ManejaMouse);
}

GLfloat Window::getXChange()
{
	GLfloat theChange = xChange;
	xChange = 0.0f;
	return theChange;
}

GLfloat Window::getYChange()
{
	GLfloat theChange = yChange;
	yChange = 0.0f;
	return theChange;
}

void Window::ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode)
{
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, GL_TRUE);

	if (key >= 0 && key < 1024) {
		if (action == GLFW_PRESS)   theWindow->keys[key] = true;
		if (action == GLFW_RELEASE) theWindow->keys[key] = false;
	}

	// orejas � F izq, G der
	if (key == GLFW_KEY_F && (action == GLFW_PRESS || action == GLFW_REPEAT))
		theWindow->articulacion1 += 1.0f;
	if (key == GLFW_KEY_G && (action == GLFW_PRESS || action == GLFW_REPEAT))
		theWindow->articulacion2 += 1.0f;

	// cola � K seg1, L seg2
	if (key == GLFW_KEY_K && (action == GLFW_PRESS || action == GLFW_REPEAT))
		theWindow->articulacion3 += 1.0f;
	if (key == GLFW_KEY_L && (action == GLFW_PRESS || action == GLFW_REPEAT))
		theWindow->articulacion4 += 1.0f;

	// pata delantera derecha � Z muslo, X canilla
	if (key == GLFW_KEY_Z && (action == GLFW_PRESS || action == GLFW_REPEAT))
		theWindow->articulacion5 += 1.0f;
	if (key == GLFW_KEY_X && (action == GLFW_PRESS || action == GLFW_REPEAT))
		theWindow->articulacion6 += 1.0f;

	// pata delantera izquierda � C muslo, V canilla
	if (key == GLFW_KEY_C && (action == GLFW_PRESS || action == GLFW_REPEAT))
		theWindow->articulacion7 += 1.0f;
	if (key == GLFW_KEY_V && (action == GLFW_PRESS || action == GLFW_REPEAT))
		theWindow->articulacion8 += 1.0f;

	// pata trasera derecha � B muslo, N canilla
	if (key == GLFW_KEY_B && (action == GLFW_PRESS || action == GLFW_REPEAT))
		theWindow->articulacion9 += 1.0f;
	if (key == GLFW_KEY_N && (action == GLFW_PRESS || action == GLFW_REPEAT))
		theWindow->articulacion10 += 1.0f;

	// pata trasera izquierda � M muslo, , canilla
	if (key == GLFW_KEY_M && (action == GLFW_PRESS || action == GLFW_REPEAT))
		theWindow->articulacion11 += 1.0f;
	if (key == GLFW_KEY_COMMA && (action == GLFW_PRESS || action == GLFW_REPEAT))
		theWindow->articulacion12 += 1.0f;
}

void Window::ManejaMouse(GLFWwindow* window, double xPos, double yPos)
{
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

	if (theWindow->mouseFirstMoved)
	{
		theWindow->lastX = xPos;
		theWindow->lastY = yPos;
		theWindow->mouseFirstMoved = false;
	}

	theWindow->xChange = xPos - theWindow->lastX;
	theWindow->yChange = theWindow->lastY - yPos;
	theWindow->lastX = xPos;
	theWindow->lastY = yPos;
}

Window::~Window()
{
	glfwDestroyWindow(mainWindow);
	glfwTerminate();
}