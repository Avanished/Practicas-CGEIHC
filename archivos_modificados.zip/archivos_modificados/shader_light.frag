#version 330

in vec4 vCol;
in vec2 TexCoord;
in vec3 Normal;
in vec3 FragPos;
in vec4 vColor;

out vec4 color;

const int MAX_POINT_LIGHTS = 3;
const int MAX_SPOT_LIGHTS = 10;

struct Light
{
    vec3 color;
    float ambientIntensity;
    float diffuseIntensity;
};

struct DirectionalLight 
{
    Light base;
    vec3 direction;
};

struct PointLight
{
    Light base;
    vec3 position;
    float constant;
    float linear;
    float exponent;
};

struct SpotLight
{
    PointLight base;
    vec3 direction;
    float edge;
};

struct Material
{
    float specularIntensity;
    float shininess;
};

uniform int pointLightCount;
uniform int spotLightCount;

uniform DirectionalLight directionalLight;
uniform PointLight pointLights[MAX_POINT_LIGHTS];
uniform SpotLight spotLights[MAX_SPOT_LIGHTS];

uniform sampler2D theTexture;
uniform Material material;
uniform vec3 eyePosition;

// MUY IMPORTANTE: por defecto visible
uniform float objectAlpha = 1.0f;

vec3 GetWorkingNormal()
{
    return normalize(Normal);
}

vec4 CalcLightByDirection(Light light, vec3 direction)
{
    vec3 norm = GetWorkingNormal();

    vec4 ambientcolor = vec4(light.color, 1.0f) * light.ambientIntensity;

    vec3 lightDir = normalize(-direction);
    float diffuseFactor = max(dot(norm, lightDir), 0.0f);
    vec4 diffusecolor = vec4(light.color * light.diffuseIntensity * diffuseFactor, 1.0f);

    vec4 specularcolor = vec4(0, 0, 0, 0);

    if (diffuseFactor > 0.0f)
    {
        vec3 fragToEye = normalize(eyePosition - FragPos);
        vec3 reflectedVertex = normalize(reflect(-lightDir, norm));

        float specularFactor = max(dot(fragToEye, reflectedVertex), 0.0f);
        if (specularFactor > 0.0f)
        {
            specularFactor = pow(specularFactor, material.shininess);
            specularcolor = vec4(light.color * material.specularIntensity * specularFactor, 1.0f);
        }
    }

    return (ambientcolor + diffusecolor + specularcolor);
}

vec4 CalcDirectionalLight()
{
    return CalcLightByDirection(directionalLight.base, directionalLight.direction);
}

vec4 CalcPointLight(PointLight pLight)
{
    vec3 direction = FragPos - pLight.position;
    float distance = length(direction);
    direction = normalize(direction);

    vec4 lightColor = CalcLightByDirection(pLight.base, direction);

    float attenuation = pLight.exponent * distance * distance +
                        pLight.linear * distance +
                        pLight.constant;

    return (lightColor / attenuation);
}

vec4 CalcSpotLight(SpotLight sLight)
{
    vec3 rayDirection = normalize(FragPos - sLight.base.position);
    vec3 spotDirection = normalize(sLight.direction);

    float slFactor = dot(rayDirection, spotDirection);

    if (slFactor > sLight.edge)
    {
        vec4 lightColor = CalcPointLight(sLight.base);
        float intensity = clamp((slFactor - sLight.edge) / (1.0f - sLight.edge), 0.0f, 1.0f);
        return lightColor * intensity;
    }
    else
    {
        return vec4(0, 0, 0, 0);
    }
}

vec4 CalcPointLights()
{
    vec4 totalcolor = vec4(0, 0, 0, 0);

    for (int i = 0; i < pointLightCount; i++)
    {
        totalcolor += CalcPointLight(pointLights[i]);
    }

    return totalcolor;
}

vec4 CalcSpotLights()
{
    vec4 totalcolor = vec4(0, 0, 0, 0);

    for (int i = 0; i < spotLightCount; i++)
    {
        totalcolor += CalcSpotLight(spotLights[i]);
    }

    return totalcolor;
}

void main()
{
    vec4 texColor = texture(theTexture, TexCoord);

    vec4 finalcolor = CalcDirectionalLight();
    finalcolor += CalcPointLights();
    finalcolor += CalcSpotLights();

    vec4 result = texColor * vColor * finalcolor;

    float alpha = texColor.a * objectAlpha;

    if (alpha < 0.02f)
        discard;

    color = vec4(result.rgb, alpha);
}